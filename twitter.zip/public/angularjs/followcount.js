//loading the 'login' angularJS module

var fca = angular.module('followCntApp', []);
//defining the login controller
fca.controller('followCntCtrl', function($scope, $http) {
	//Initializing the 'invalid_login' and 'unexpected_error' 
	//to be hidden in the UI by setting them true,
	//Note: They become visible when we set them to false
	//alert(req.session.userid2);
	//alert($('#userid2').val());
	

	

});

